from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, field_validator
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List, Optional
import aiosqlite
import os

DB_PATH = os.getenv("DB_PATH", "manicure.db")

# ── Pydantic-модели ──────────────────────────────────────────────────────────

class AppointmentCreate(BaseModel):
    client_name: str
    phone: str
    service: str
    appointment_date: datetime   # принимает ISO-строку: "2025-06-10T14:00:00"

    @field_validator("client_name")
    @classmethod
    def name_not_empty(cls, v: str) -> str:
        if len(v.strip()) < 2:
            raise ValueError("Имя должно содержать минимум 2 символа")
        return v.strip()

class AppointmentReschedule(BaseModel):
    new_date: datetime

class AppointmentOut(BaseModel):
    id: int
    client_name: str
    phone: str
    service: str
    appointment_date: datetime
    created_at: datetime

# ── Инициализация БД ─────────────────────────────────────────────────────────

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS appointments (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                client_name      TEXT    NOT NULL,
                phone            TEXT    NOT NULL,
                service          TEXT    NOT NULL,
                appointment_date TEXT    NOT NULL,
                created_at       TEXT    DEFAULT (datetime('now'))
            )
        """)
        await db.commit()

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()       # запускается один раз при старте сервера
    yield

app = FastAPI(title="Маникюр — сервис записей", lifespan=lifespan)

# ── Вспомогательная функция ──────────────────────────────────────────────────

def row_to_dict(row, cursor):
    """Превращает строку из БД в словарь по именам столбцов."""
    cols = [col[0] for col in cursor.description]
    return dict(zip(cols, row))

# ── Эндпоинты ────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/", response_class=HTMLResponse)
async def frontend():
    """Отдаёт HTML-фронтенд."""
    path = os.path.join(os.path.dirname(__file__), "frontend.html")
    with open(path, encoding="utf-8") as f:
        return f.read()


@app.get("/appointments", response_model=List[AppointmentOut])
async def list_appointments():
    """Получить все заявки, отсортированные по дате."""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT * FROM appointments ORDER BY appointment_date"
        )
        rows = await cursor.fetchall()
        return [row_to_dict(r, cursor) for r in rows]


@app.get("/appointments/{appointment_id}", response_model=AppointmentOut)
async def get_appointment(appointment_id: int):
    """Получить одну заявку по ID."""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT * FROM appointments WHERE id = ?", (appointment_id,)
        )
        row = await cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Заявка не найдена")
        return row_to_dict(row, cursor)


@app.post("/appointments", status_code=201, response_model=AppointmentOut)
async def create_appointment(data: AppointmentCreate):
    """Создать новую заявку."""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            """INSERT INTO appointments (client_name, phone, service, appointment_date)
               VALUES (?, ?, ?, ?)""",
            (data.client_name, data.phone, data.service, data.appointment_date.isoformat())
        )
        await db.commit()

        cursor2 = await db.execute(
            "SELECT * FROM appointments WHERE id = ?", (cursor.lastrowid,)
        )
        row = await cursor2.fetchone()
        return row_to_dict(row, cursor2)


@app.patch("/appointments/{appointment_id}/reschedule", response_model=AppointmentOut)
async def reschedule_appointment(appointment_id: int, data: AppointmentReschedule):
    """Перенести заявку на другую дату."""
    async with aiosqlite.connect(DB_PATH) as db:
        # проверяем существование
        cursor = await db.execute(
            "SELECT id FROM appointments WHERE id = ?", (appointment_id,)
        )
        if not await cursor.fetchone():
            raise HTTPException(status_code=404, detail="Заявка не найдена")

        await db.execute(
            "UPDATE appointments SET appointment_date = ? WHERE id = ?",
            (data.new_date.isoformat(), appointment_id)
        )
        await db.commit()

        cursor2 = await db.execute(
            "SELECT * FROM appointments WHERE id = ?", (appointment_id,)
        )
        row = await cursor2.fetchone()
        return row_to_dict(row, cursor2)


@app.delete("/appointments/{appointment_id}", status_code=204)
async def delete_appointment(appointment_id: int):
    """Удалить заявку."""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT id FROM appointments WHERE id = ?", (appointment_id,)
        )
        if not await cursor.fetchone():
            raise HTTPException(status_code=404, detail="Заявка не найдена")

        await db.execute(
            "DELETE FROM appointments WHERE id = ?", (appointment_id,)
        )
        await db.commit()
    return None
