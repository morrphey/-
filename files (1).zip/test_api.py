"""
Тесты для маникюр-сервиса.
Запуск: pytest tests/
"""
import pytest
import pytest_asyncio
import aiosqlite
from httpx import AsyncClient, ASGITransport

# conftest.py уже установил DB_PATH=test_manicure.db до этого импорта
from app.main import app, init_db

TEST_DB = "test_manicure.db"


@pytest_asyncio.fixture(autouse=True)
async def clean_db():
    """Перед каждым тестом создаём таблицу и очищаем её."""
    await init_db()
    async with aiosqlite.connect(TEST_DB) as db:
        await db.execute("DELETE FROM appointments")
        await db.commit()
    yield


# Хелпер — создаёт AsyncClient один раз, используется в каждом тесте
async def get_client():
    return AsyncClient(transport=ASGITransport(app=app), base_url="http://test")


# ── Тест 1: /health возвращает ok ────────────────────────────────────────────
@pytest.mark.asyncio
async def test_health():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        r = await client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


# ── Тест 2: создание и получение заявки ─────────────────────────────────────
@pytest.mark.asyncio
async def test_create_and_list():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:

        # создаём заявку
        r = await client.post("/appointments", json={
            "client_name": "Анна",
            "phone": "+7 999 111 22 33",
            "service": "Маникюр классический",
            "appointment_date": "2025-07-01T14:00:00"
        })
        assert r.status_code == 201
        created = r.json()
        assert created["client_name"] == "Анна"
        assert created["service"] == "Маникюр классический"

        # список должен содержать одну запись
        r2 = await client.get("/appointments")
        assert r2.status_code == 200
        assert len(r2.json()) == 1


# ── Тест 3: удаление заявки ──────────────────────────────────────────────────
@pytest.mark.asyncio
async def test_delete_appointment():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:

        # сначала создаём
        r = await client.post("/appointments", json={
            "client_name": "Мария",
            "phone": "+7 999 000 00 00",
            "service": "Педикюр",
            "appointment_date": "2025-07-02T10:00:00"
        })
        aid = r.json()["id"]

        # удаляем
        r2 = await client.delete(f"/appointments/{aid}")
        assert r2.status_code == 204

        # повторный GET должен вернуть 404
        r3 = await client.get(f"/appointments/{aid}")
        assert r3.status_code == 404
