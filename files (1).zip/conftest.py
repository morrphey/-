import os
# Устанавливаем переменную ДО того как pytest импортирует app/main.py
os.environ["DB_PATH"] = "test_manicure.db"
